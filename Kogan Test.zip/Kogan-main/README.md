# Kogan Test

## Setup / Run Instructions

Language: Python3.6

In the root directory of the project run:

pip3 install -r requirements.txt

Run program with command:

python3 main.py
